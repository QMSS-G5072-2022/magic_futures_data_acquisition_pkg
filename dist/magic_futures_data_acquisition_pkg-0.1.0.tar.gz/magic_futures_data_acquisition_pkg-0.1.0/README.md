# magic_futures_data_acquisition_pkg

The package is used to acquist futures data from JoinQuant. The functions can automatically download the data to local. Because the JoinQuant API has access limit, the funcnction can automatically detect where you left last time and continue downloading new data. Also, it can help detect the missing data.

## Installation

```bash
$ pip install magic_futures_data_acquisition_pkg
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`magic_futures_data_acquisition_pkg` was created by zw2744. It is licensed under the terms of the MIT license.

## Credits

`magic_futures_data_acquisition_pkg` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
