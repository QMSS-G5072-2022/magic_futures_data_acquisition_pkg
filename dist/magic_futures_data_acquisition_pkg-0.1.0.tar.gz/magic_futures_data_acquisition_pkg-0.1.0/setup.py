# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['magic_futures_data_acquisition_pkg']

package_data = \
{'': ['*']}

install_requires = \
['datetime>=4.7,<5.0',
 'jqdatasdk>=1.8.11,<2.0.0',
 'pandas>=1.5.2,<2.0.0',
 'python-dotenv>=0.21.0,<0.22.0']

setup_kwargs = {
    'name': 'magic-futures-data-acquisition-pkg',
    'version': '0.1.0',
    'description': 'The package is used to acquist futures data from JoinQuant. The functions can automatically download the data to local. Because the JoinQuant API has access limit, the funcnction can automatically detect where you left last time and continue downloading new data. Also, it can help detect the missing data.',
    'long_description': '# magic_futures_data_acquisition_pkg\n\nThe package is used to acquist futures data from JoinQuant. The functions can automatically download the data to local. Because the JoinQuant API has access limit, the funcnction can automatically detect where you left last time and continue downloading new data. Also, it can help detect the missing data.\n\n## Installation\n\n```bash\n$ pip install magic_futures_data_acquisition_pkg\n```\n\n## Usage\n\n- TODO\n\n## Contributing\n\nInterested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.\n\n## License\n\n`magic_futures_data_acquisition_pkg` was created by zw2744. It is licensed under the terms of the MIT license.\n\n## Credits\n\n`magic_futures_data_acquisition_pkg` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).\n',
    'author': 'zw2744',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
